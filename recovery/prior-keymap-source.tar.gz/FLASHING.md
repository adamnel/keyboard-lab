# Flashing Corne CRKBD rev4.1 — `adam_miryoku`

Bookmark this when you update firmware. The **same** `qmk compile` / `qmk flash` lines also appear in [AGENTS.md](AGENTS.md) and [REQUIREMENTS.md](REQUIREMENTS.md); this file is the full procedure.

---

## Prerequisites

- [QMK build environment](https://docs.qmk.fm/#/getting_started_build_tools) (CLI, toolchain).
- Shell **working directory:** the root of this QMK repo (where `Makefile` lives).

---

## Build only (check it compiles)

```bash
qmk compile -kb crkbd/rev4_1/standard -km adam_miryoku
```

Output firmware is typically under `.build/` (e.g. `crkbd_rev4_1_standard_adam_miryoku.uf2` for RP2040).

---

## Manual UF2 flash (`RPI-RP2` drive)

When the half is in bootloader mode, macOS mounts a drive named **`RPI-RP2`**. It is **normal** for it to only show **`index.html`** and **`INFO_UF2.TXT`** (bootloader files from the chip). You do **not** replace those with the firmware.

1. Build (or use a `.uf2` you already built):

   ```bash
   qmk compile -kb crkbd/rev4_1/standard -km adam_miryoku
   ```

2. Find the firmware file in your QMK repo:

   **`.build/crkbd_rev4_1_standard_adam_miryoku.uf2`**

   (Same folder name pattern if you change keymap: `crkbd_rev4_1_standard_<keymap>.uf2`.)

3. **Copy or drag** that **`.uf2` file** onto the **`RPI-RP2` drive root** — the **same level** as `index.html`, not inside a subfolder. The RP2040 watches for a **new** `.uf2` there and flashes it; the volume usually **ejects by itself** when done.

4. Repeat for the **other** half with the **same** `.uf2` if needed.

If you don’t see `.build/…uf2`, run `compile` first from the repo root, or check for a copy at the repo root (some setups copy the UF2 next to `Makefile`).

---

## Flash over USB

```bash
qmk flash -kb crkbd/rev4_1/standard -km adam_miryoku
```

1. Connect **only the half** you are flashing via USB (disconnect the TRRS cable to the other half if needed).
2. Put that half into the **bootloader** (see **Bootloader on this board** below).
3. Run the command above; QMK should find the device and flash. If auto-flash fails, copy the `.uf2` from `.build/` onto the bootloader USB drive manually.
4. **Repeat for the other half** with the **same** firmware — both controllers need the same image.

Optional: [QMK newbs flashing guide](https://docs.qmk.fm/#/newbs_flashing).

---

## Physical hardware (logged) + QMK target

**Retail unit (Adam’s board):** [YMDK Corne V4.1 — 46 keys, split, wired](https://www.amazon.com/dp/B0F9FDZZNN).

| Field | Value |
|-------|--------|
| **QMK** `-kb` | `crkbd/rev4_1/standard` |
| **QMK** `-km` | `adam_miryoku` |
| Upstream design | **Corne / CRKBD** [foostan](https://github.com/foostan/crkbd), **v4.1**, **RP2040** ([`info.json`](keyboards/crkbd/rev4_1/info.json)) |

Behavior (matrix, Bootmagic, flashing) comes from **`keyboards/crkbd/rev4_1/`** plus your keymap’s **layout macro** (`LAYOUT_split_3x6_3_ex2`). The Amazon listing is **human reference** only; if hardware ever diverges from `rev4_1/standard`, update this note.

---

## Bootloader (Bootmagic — hold a key, no separate boot button)

**RP2040** + **Bootmagic** enabled. Boot keys are fixed by **matrix coordinates** in [keyboards/crkbd/rev4_1/info.json](keyboards/crkbd/rev4_1/info.json): **`[0, 1]`** on the left half, **`[4, 1]`** on the right half.

Your **`adam_miryoku`** keymap uses **`LAYOUT_split_3x6_3_ex2`** ([`config.h`](keyboards/crkbd/rev4_1/standard/keymaps/adam_miryoku/config.h)), i.e. **seven** top-row positions per half: outer placeholder, **five** alphas, outer placeholder (`XXX … K00–K04 … XXX` / `XXX … K05–K09 … XXX`). In that layout, matrix **`[0, 1]`** is **`K00`**, and **`[4, 1]`** is **`K09`** (see [`LAYOUT_split_3x6_3_ex2`](keyboards/crkbd/rev4_1/info.json) column order).

So on **Miryoku QWERTY**:

| Half | Bootmagic cell | Key |
|------|------------------|-----|
| **Left** | `[0, 1]` | **Q** (first **letter** on the top row — one in from the outer edge) |
| **Right** | `[4, 1]` | **P** (first **letter** from the **outer** pinky — one in from the outside `XXX`) |

**How to use:** Hold **Q** (left) or **P** (right), then plug USB into that half (same idea as [crkbd readme](keyboards/crkbd/readme.md) “Q and P” — here it matches the **`ex2`** matrix mapping, not a guess from a different layout).

If you switch to a **different layout macro** (e.g. without outer columns), **`[0,1]` / `[4,1]`** may label as **different letters** — use the **same matrix positions** or re-check `info.json` for your board target.

**Other options (hardware-dependent):**

- **RP2040 double-tap reset:** [rev4_1 `config.h`](keyboards/crkbd/rev4_1/config.h) defines `RP2040_BOOTLOADER_DOUBLE_TAP_RESET` if a **reset** pad/button is available.

---

## Overrides at flash time

Prefer long-term options in [users/adam_miryoku/custom_rules.mk](users/adam_miryoku/custom_rules.mk). To override once:

```bash
qmk flash -kb crkbd/rev4_1/standard -km adam_miryoku -e MIRYOKU_CLIPBOARD=MAC -e MIRYOKU_LAYERS=FLIP
```

---

## See also

- [REQUIREMENTS.md](REQUIREMENTS.md) — build defaults and keymap goals  
- [AGENTS.md](AGENTS.md) — short agent entry + same commands  
