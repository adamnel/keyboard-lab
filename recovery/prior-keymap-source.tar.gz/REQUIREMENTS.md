# Adam CRKBD Miryoku — Requirements note

**Authoritative** requirements and configuration for the Corne (CRKBD) rev4.1 `adam_miryoku` keymap. [AGENTS.md](AGENTS.md) is the short entry point and links here; agents must **validate changes against this document** (see AGENTS.md policy).

---

## Project facts

| Item | Value |
|------|--------|
| Retail reference | [YMDK Corne V4.1 46-key split](https://www.amazon.com/dp/B0F9FDZZNN) (Amazon ASIN — not used by QMK; build with `-kb crkbd/rev4_1/standard -km adam_miryoku`) |
| Keyboard | Corne (CRKBD) rev4.1, standard layout |
| Keymap | `adam_miryoku` (Miryoku-based) |
| Branch | `feature/adam-crkbd-macos-keypad` |
| OS target | macOS (Cmd-based clipboard shortcuts) |

### Repository paths

| Purpose | Path |
|---------|------|
| Keymap entry | `keyboards/crkbd/rev4_1/standard/keymaps/adam_miryoku/` |
| Userspace | `users/adam_miryoku/` |
| Runtime / tuning | `users/adam_miryoku/custom_config.h` |
| Build options | `users/adam_miryoku/custom_rules.mk` |
| Layer macros | `users/adam_miryoku/miryoku_babel/` |
| Keymap reference | `users/adam_miryoku/KEYMAP.md` |

### Build

```bash
qmk compile -kb crkbd/rev4_1/standard -km adam_miryoku
qmk flash   -kb crkbd/rev4_1/standard -km adam_miryoku
```

**Full flashing procedure** (split halves, bootloader, UF2): [FLASHING.md](FLASHING.md).

---

## Current build defaults (`custom_rules.mk`)

These are set so normal builds do not need `-e` overrides:

| Option | Value | Notes |
|--------|--------|--------|
| `MIRYOKU_ALPHAS` | `QWERTY` | Base alphas (Miryoku default without this is Colemak-DH). |
| `MIRYOKU_TAP` | `QWERTY` | Tap layer plain alphas match QWERTY (default Tap is Colemak-DH). |
| `MIRYOKU_CLIPBOARD` | `MAC` | Cut/copy/paste/undo/redo use Cmd; see `adam_miryoku.h` (`U_CPY`, `U_PST`, etc.). |
| `MIRYOKU_LAYERS` | `FLIP` | Sub-layers swapped between hands (Num/Sym/Fun vs Nav/Mouse/Media). |

---

## Miryoku + FLIP behavior (baseline)

- **`MIRYOKU_LAYERS=FLIP`**: Thumb-triggered layers are mirrored — content for a layer appears on the **opposite** hand from the thumb that holds the layer key.
- With FLIP, **Num / Sym / Fun** are accessed with the **left** thumb; their **content** is on the **right** hand.
- **Nav / Mouse / Media** are accessed with the **right** thumb; their **content** is on the **left** hand.

Thumb → opposite hand (FLIP), from `KEYMAP.md`:

| Hold (left thumb) | Right hand shows |
|-------------------|------------------|
| Backspace (primary) | Num |
| Enter (secondary) | Sym |
| Delete (tertiary) | Fun |

| Hold (right thumb) | Left hand shows |
|--------------------|-----------------|
| Tab (primary) | Mouse |
| Space (secondary) | Nav |
| Escape (tertiary) | Media |

**Space** on the **right** thumb (secondary) is part of the stock Miryoku mapping above.

---

## Product requirements (to satisfy / track)

### 1. Numpad on the right without using the left hand

**Goal:** Enter digits and keypad-related keys using **only the right hand**, with **no** use of the left hand (any finger, including thumb).

**Relation to current setup:** **Not met** by stock Miryoku **FLIP**. Num content is on the **right** hand, but you must **hold the Num layer with the left thumb** (Backspace). That still uses the left hand, so it **does not** satisfy this requirement as written.

**Possible directions (future):** e.g. **layer lock** / **one-shot layer** so the right hand can type digits without a held layer key, a **default-layer numpad** region on the right, or another scheme that removes the need for any left-hand involvement during numpad entry.

---

### 2. Window manager workspace switching on the left without using the right hand

**Goal:** Switch virtual desktops / workspaces using only the **left** hand (no right-hand keys required). This is a **high-frequency** operation — speed is critical.

**Interaction model:** Hold **one** left-thumb key (the WM layer key), then tap **any left-hand alpha** to trigger the corresponding workspace/WM action. This must be a simple **hold + tap** — the fastest possible pattern. **All 15 left-hand alpha positions** (3×5 grid) are reserved for WM bindings; they **cannot** be shared with other functions (modifiers, tap-dances, etc.) on this layer. Tab and Tilde positions on this layer are also needed for WM actions (app switching, window cycling).

**Non-negotiable:** No combos, no multi-tap, no timing-dependent mechanisms for WM triggers. A single layer-hold + single key-tap must fire the WM chord instantly.

**Relation to current setup:** The current custom Sym layer (`ADAM_WM`) maps the left-hand 3×5 grid to `Ctrl+Cmd+letter`. This satisfies the interaction model. The stock Sym left-hand keys it replaced (TD Boot/Tap/Extra/Base, home-row mods Cmd/Alt/Ctrl/Shift, AltGr, TD Mouse/Sym) are **not valuable** — confirmed expendable. No dedicated WM layer is needed; repurposing Sym left-hand is the accepted approach.

**Open:** Confirm target WM (e.g. macOS Spaces, yabai, Amethyst) and exact key chords.

---

### 3. Space on the right side

**Goal:** **Space** remains on the **right** thumb (secondary right thumb in Miryoku FLIP), consistent with typing and Nav access.

**Relation to current setup:** Satisfied by default Miryoku FLIP thumb map (see table above). Document any future change that would move Space.

---

### 4. Common macOS shortcuts on the left without using the right hand

**Goal:** With **only the left hand**, be able to send **Command + letter** (and similar) so macOS applies shortcuts **by chord**, not by hardcoding each app action in firmware.

**What we need:**

- **Hold Command** on the left hand (as a normal modifier), then press letters such as **T** and **S** on the **same** hand so the OS sees **⌘T**, **⌘S**, **⌘N**, etc. No requirement that each shortcut be a **dedicated keycode** in the keymap (contrast: clipboard-specific macros like `U_UND` are optional convenience, not the model for this requirement).

**Relation to current setup:** Miryoku **base** maps **Cmd** to the left **pinky** home key (`LGUI_T` on **A** in QWERTY). Holding Cmd and tapping **T**, **S**, … on the left should produce standard macOS chords **without** extra per-action definitions, as long as mod-tap / modifier hold behavior works for your typing. **Nav** (hold right-thumb Space) adds dedicated clipboard keys on the left; that is supplementary, not a substitute for composable **⌘+letter** on base.

**Known conflict — ⌘A (Select All):** Because Cmd **is** the A key (`LGUI_T(KC_A)`), there is no way to produce **Cmd+A** left-hand-only — holding A activates the modifier, and there is no second A to tap. The right hand can press **H** (`RSFT_T(KC_H)`) shift-side, but that is Shift, not A. Possible mitigations:

- Use the **right-hand A key equivalent** (not available in Miryoku — right pinky is `'`).
- Add a **dedicated `LGUI(KC_A)` key** (e.g. combo, or on Nav/Sym left hand).
- Use an **OSM(MOD_LGUI) approach** instead of `LGUI_T(KC_A)` so Cmd and A are separate actions (bigger change to home-row mods).

**Status:** Partially met — composable ⌘+letter works for all left-hand letters **except A**. ⌘A requires a workaround.

**Validate:** Cmd held + at least **T** and **S** on the left reach the host as **Cmd+key**, right hand unused. Separately validate that **⌘A** is reachable via chosen mitigation.

---

### 5. One-key shortcuts for app / window switching (left hand, on WM layer)

**Goal:** The following four macOS / WM chords must be available on the **WM layer** (same layer as Req 2), triggered by a single tap while holding the WM layer key. They are part of the WM workflow and are used at **high frequency**.

| Shortcut | macOS function | QMK keycode | Placement |
|----------|----------------|-------------|-----------|
| **⌘ + Tab** | Switch apps forward | `LGUI(KC_TAB)` | WM layer, left hand |
| **⌘ + Shift + Tab** | Switch apps backward | `SGUI(KC_TAB)` | WM layer, left hand |
| **⌘ + `~`** | Switch windows within the same app | `LGUI(KC_GRV)` | WM layer, left hand |
| **Hyper + Tab** | Window-manager action (app-specific) | `HYPR(KC_TAB)` | WM layer, left hand |

**Constraints:**

- Must be reachable with the **left hand only** (right hand on trackpad).
- Must live on the **WM layer** alongside workspace bindings (Req 2), activated by the same left-thumb hold.
- **Hold + tap** only — same interaction model as Req 2. No combos, no multi-tap.
- For ⌘Tab cycling (hold Cmd while tapping Tab repeatedly), the WM layer key or a macro must keep Cmd registered so repeated taps cycle through apps without re-chording.

**Relation to current setup:** Not yet implemented. The current custom Sym layer has WM letter bindings but no Tab/Tilde/Hyper+Tab shortcuts and no ⌘Tab cycling support.

---

## Community research (QMK / Miryoku patterns)

See **[RESEARCH.md](RESEARCH.md)** for Layer Lock, tap-toggle, one-shot layers/modifiers, workspace key ideas, and how they relate to each requirement.

---

## References

- [AGENTS.md](AGENTS.md) — agent entry point (validation policy, quick links)  
- [RESEARCH.md](RESEARCH.md) — community patterns for numpad lock, ⌘+letter, WM keys  
- [users/adam_miryoku/readme.org](users/adam_miryoku/readme.org) — Miryoku QMK readme  
- [Miryoku reference (upstream)](https://github.com/manna-harbour/miryoku/blob/master/docs/reference/readme.org)  
- [keyboards/crkbd/readme.md](keyboards/crkbd/readme.md) — CRKBD hardware readme  
