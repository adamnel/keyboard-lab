// Copyright 2019 Manna Harbour
// https://github.com/manna-harbour/miryoku

// This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

#pragma once

// Sym layer (FLIP): left-hand alpha grid sends Ctrl+Cmd+letter for window-manager bindings.
#if defined(MIRYOKU_LAYERS_FLIP)
#  define MIRYOKU_LAYER_SYM MIRYOKU_ALTERNATIVES_SYM_ADAM_FLIP
#endif
