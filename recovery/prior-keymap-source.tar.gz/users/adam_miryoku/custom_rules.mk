# Copyright 2019 Manna Harbour
# https://github.com/manna-harbour/miryoku

# QWERTY alpha layout (default is Colemak-DH)
MIRYOKU_ALPHAS = QWERTY

# Tap layer: plain alphas without home-row mods (default is Colemak-DH)
MIRYOKU_TAP = QWERTY

# macOS: Cmd for cut/copy/paste/undo/redo
MIRYOKU_CLIPBOARD = MAC

# Keypad (Num) layer on right hand; Nav/Mouse/Media on left
MIRYOKU_LAYERS = FLIP

