# Adam Miryoku Keymap Reference

**Keyboard:** Corne (CRKBD) rev4.1 standard  
**Build:** `qmk compile -kb crkbd/rev4_1/standard -km adam_miryoku`

## Configuration


| Option            | Value     | Effect                                                 |
| ----------------- | --------- | ------------------------------------------------------ |
| MIRYOKU_CLIPBOARD | MAC       | Cut/Copy/Paste/Undo/Redo use **Cmd** (not Ctrl)        |
| MIRYOKU_LAYERS    | FLIP      | **Num/Sym/Fun on right hand**, Nav/Mouse/Media on left |
| MIRYOKU_ALPHAS    | QWERTY   | QWERTY alpha layout                                    |


---

## Layout Convention

Tables use **10 logical columns per row** (`K00`–`K09` in firmware): **cols 0–4** = left hand, **cols 5–9** = right hand. That matches Miryoku’s layer macros, not the raw matrix width.

**Physical Corne:** each half is **3×6 + 3** thumbs. `config.h` wraps the Miryoku matrix with **`XXX`** (`KC_NO`) on the outer columns so the PCB matches `LAYOUT_split_3x6_3_ex2`. Those pads have no keycaps; the diagrams below are the **logical** layout you program.

- **Thumbs** (bottom row of each table): cells left **blank** are `U_NP` in firmware—outer thumb matrix positions with **no key** on a normal Corne (placeholders so the row has the right length). The real thumb keys are the inner columns (`Del` / `Bspc` / `Ent` on the left, `Tab` / `Space` / `Esc` on the right in base).

- **Layer key** on one hand → **layer content** on the **opposite** hand (FLIP: Num/Sym/Fun on the right; Nav/Mouse/Media on the left).

**Legend:** `TD(…)` = tap-dance (layer / boot); **(blank)** = `U_NP` (no physical key at that matrix slot); **—** = `U_NA` / `U_NU` (physical key exists but no binding on this layer); **OU** = one-shot user (`OU_AUTO`, RGB underglow control on some builds).

### Layer Activation (FLIP)


| Hold (left thumb)       | Right hand shows |
| ----------------------- | ---------------- |
| **Backspace** (primary) | Num              |
| **Enter** (secondary)   | Sym              |
| **Delete** (tertiary)   | Fun              |



| Hold (right thumb)    | Left hand shows |
| --------------------- | --------------- |
| **Tab** (primary)     | Mouse           |
| **Space** (secondary) | Nav             |
| **Escape** (tertiary) | Media           |


---

## Base Layer (QWERTY)

**Home row mods** (tap = key, hold = modifier): Cmd / Alt / Ctrl / Shift, mirrored.


|            | Col 0 | Col 1 | Col 2     | Col 3      | Col 4     |     | Col 5       | Col 6     | Col 7       | Col 8 | Col 9 |
| ---------- | ----- | ----- | --------- | ---------- | --------- | --- | ----------- | --------- | ----------- | ----- | ----- |
| **Row 0**  | Q     | W     | E         | R          | T         |     | Y           | U         | I           | O     | P     |
| **Row 1**  | A     | S     | D         | F          | G         |     | H           | J         | K           | L     | '     |
| **Row 2**  | Z     | X     | C         | V          | B         |     | N           | M         | ,           | .     | /     |
| **Thumbs** |       |       | Del / Fun | Bspc / Num | Ent / Sym |     | Tab / Mouse | Spc / Nav | Esc / Media |       |       |


*Row 1: Cols 1–4 = Cmd/Alt/Ctrl/Shift (hold); Cols 6–9 = Shift/Ctrl/Alt/Cmd (hold).*

---

## Extra Layer

Same as Base but with Colemak Mod-DH alphas (default alt layout). Activate via double-tap top row index key (when holding a layer key).

---

## Tap Layer

Base without home-row mods—plain alphas only. Activate via double-tap top row middle key.

---

## Nav Layer *(hold Space on right thumb)*

Cursor, clipboard, and layer switches. **Left hand** has Nav content; **right hand** has layer tap-dances and mods.


|            | Col 0 | Col 1 | Col 2 | Col 3 | Col 4 |     | Col 5 | Col 6 | Col 7 | Col 8 | Col 9 |
| ---------- | ----- | ----- | ----- | ----- | ----- | --- | ----- | ----- | ----- | ----- | ----- |
| **Row 0**  | Home  | PgDn  | PgUp  | End   | Ins   |     | —     | TD(Base) | TD(Extra) | TD(Tap) | TD(Boot) |
| **Row 1**  | ←     | ↓     | ↑     | →     | Caps Word |     | —     | Shift | Ctrl | Alt | Cmd |
| **Row 2**  | Undo  | Cut   | Copy  | Paste | Redo  |     | TD(Nav) | TD(Num) | AltGr | — |
| **Thumbs** |       |       | Del   | Bspc  | Enter |     | —     | —     | —     |       |       |


**Clipboard (MAC):** Undo=Cmd+Z, Cut=Cmd+X, Copy=Cmd+C, Paste=Cmd+V, Redo=Cmd+Shift+Z

---

## Mouse Layer *(hold Tab on right thumb)*

**Left hand** has mouse and wheel; **right hand** has tap-dances and mods.


|            | Col 0 | Col 1 | Col 2 | Col 3 | Col 4 |     | Col 5 | Col 6 | Col 7 | Col 8 | Col 9 |
| ---------- | ----- | ----- | ----- | ----- | ----- | --- | ----- | ----- | ----- | ----- | ----- |
| **Row 0**  | WH ←  | WH ↓  | WH ↑  | WH →  | —     |     | —     | TD(Base) | TD(Extra) | TD(Tap) | TD(Boot) |
| **Row 1**  | M ←   | M ↓   | M ↑   | M →   | —     |     | —     | Shift | Ctrl | Alt | Cmd |
| **Row 2**  | Undo  | Cut   | Copy  | Paste | Redo  |     | TD(Mouse) | TD(Sym) | AltGr | — |
| **Thumbs** |       |       | M3    | M1    | M2    |     | —     | —     | —     |       |       |


---

## Media Layer *(hold Escape on right thumb)*

**Left hand** has media / RGB; **right hand** has tap-dances and mods.


|            | Col 0 | Col 1 | Col 2 | Col 3 | Col 4 |     | Col 5 | Col 6 | Col 7 | Col 8 | Col 9 |
| ---------- | ----- | ----- | ----- | ----- | ----- | --- | ----- | ----- | ----- | ----- | ----- |
| **Row 0**  | RGB mode+ | Hue+ | Sat+ | Val+ | RGB toggle | | —     | TD(Base) | TD(Extra) | TD(Tap) | TD(Boot) |
| **Row 1**  | Prev  | Vol−  | Vol+  | Track next | —     |     | —     | Shift | Ctrl | Alt | Cmd |
| **Row 2**  | —     | —     | —     | —     | OU    |     | TD(Media) | TD(Fun) | AltGr | — |
| **Thumbs** |       |       | Mute  | Play  | Stop  |     | —     | —     | —     |       |       |


---

## Num Layer *(hold Backspace on left thumb)*

Numpad-style keys on **right hand**. Numbers 7–9 top, 4–6 middle, 1–3 bottom; `0` / `.` / `-` on thumbs.


|            | Col 0 | Col 1 | Col 2 | Col 3 | Col 4 |     | Col 5 | Col 6 | Col 7 | Col 8 | Col 9 |
| ---------- | ----- | ----- | ----- | ----- | ----- | --- | ----- | ----- | ----- | ----- | ----- |
| **Row 0**  | TD(Boot) | TD(Tap) | TD(Extra) | TD(Base) | — | | `[` | 7 | 8 | 9 | `]` |
| **Row 1**  | Cmd   | Alt   | Ctrl  | Shift | —     |     | `=` | 4 | 5 | 6 | `;` |
| **Row 2**  | —     | AltGr | TD(Nav) | TD(Num) | —     |     | Backslash | 1 | 2 | 3 | Grave |
| **Thumbs** |       |       | —     | —     | —     |     | `-` | 0 | `.` |       |       |


---

## Sym Layer *(hold Enter on left thumb)*

**Left hand:** each key in the 3×5 alpha block sends **Ctrl+Cmd+letter** for that QWERTY position (e.g. **E** → Ctrl+Cmd+E) for window-manager shortcuts. **Right hand:** same symbol layout as stock Miryoku (mirrors Num).


|            | Col 0 | Col 1 | Col 2 | Col 3 | Col 4 |     | Col 5 | Col 6 | Col 7 | Col 8 | Col 9 |
| ---------- | ----- | ----- | ----- | ----- | ----- | --- | ----- | ----- | ----- | ----- | ----- |
| **Row 0**  | ^Q    | ^W    | ^E    | ^R    | ^T    |     | `{` | `&` | `*` | `(` | `}` |
| **Row 1**  | ^A    | ^S    | ^D    | ^F    | ^G    |     | `+` | `$` | `%` | `^` | `:` |
| **Row 2**  | ^Z    | ^X    | ^C    | ^V    | ^B    |     | Pipe | ! | @ | # | ~ |
| **Thumbs** |       |       | —     | —     | —     |     | `_` | `(` | `)` |       |       |

^*letter* = Ctrl+Cmd+*letter* (implemented as `LCTL(LGUI(KC_*))`, not QMK’s four-mod `HYPR`).


---

## Fun Layer *(hold Delete on left thumb)*

Function keys on **right hand**.


|            | Col 0 | Col 1 | Col 2 | Col 3 | Col 4 |     | Col 5 | Col 6 | Col 7 | Col 8 | Col 9 |
| ---------- | ----- | ----- | ----- | ----- | ----- | --- | ----- | ----- | ----- | ----- | ----- |
| **Row 0**  | TD(Boot) | TD(Tap) | TD(Extra) | TD(Base) | — | | PrtSc | F7 | F8 | F9 | F12 |
| **Row 1**  | Cmd   | Alt   | Ctrl  | Shift | —     |     | Scroll Lock | F4 | F5 | F6 | F11 |
| **Row 2**  | —     | AltGr | TD(Media) | TD(Fun) | —     |     | Pause | F1 | F2 | F3 | F10 |
| **Thumbs** |       |       | —     | —     | —     |     | Tab | Space | Menu |       |       |


---

## Button Layer

Clipboard, mods, and mouse buttons on both hands. Activated automatically with pointing device, or manually by holding a bottom-row pinkie key.

---

## Special Functions

- **Bootloader**: Hold any thumb layer key, then double-tap pinkie column key on the same hand.
- **Caps Word**: Toggle via Caps Word key on Nav layer (middle row, index).
- **Layer lock**: Double-tap index (current layer) or middle (opposite hand’s layer) on bottom row while holding a layer key.

